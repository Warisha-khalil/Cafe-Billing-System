﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace CAFE_PROJECT
{
    public partial class Form4 : Form
    {
        OleDbConnection conn;
        OleDbCommand cmd;
        OleDbDataAdapter adapter;
        OleDbDataReader reader;
        OleDbConnection connection;
        DataTable dt;
        public Form4()
        {
            InitializeComponent();
        }
        void GetITEMS()
        {
            conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Manageitems1.accdb");
            dt = new DataTable();
            adapter = new OleDbDataAdapter("SELECT *FROM itemlist ", conn);
            conn.Open();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }
        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            String query = "UPDATE itemlist SET ITEMNUM= @itemnum,ITEMNAME=@itemname,CATEGORY=@category,ITEMPRICE=@itemprice WHERE ITEMNUM=@itemnum";
            cmd = new OleDbCommand(query, conn);
            cmd.Parameters.AddWithValue("@itemnum", textBox3.Text);
            cmd.Parameters.AddWithValue("@itemname", textBox4.Text);
            cmd.Parameters.AddWithValue("@category", comboBox1.Text);
            cmd.Parameters.AddWithValue("@itemprice", textBox5.Text);
            cmd.Parameters.AddWithValue("@itemnum", Convert.ToInt32(textBox3.Text));
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Update Sccessfully data");
            GetITEMS();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 Login = new Form1();
            Login.Show();
        }

        private void LABEL5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 form = new Form3();
            form.Show();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 form = new Form6();
            form.Show();

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            GetITEMS();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "")
            {
                MessageBox.Show("Fill all the fields");
            }
            else
            { 
            string query =
               "INSERT INTO itemlist(ITEMNUM,ITEMNAME,CATEGORY,ITEMPRICE)" +
              "VALUES(@itemnum,@itemname,@category,@itemprice)";
            cmd = new OleDbCommand(query, conn);
            cmd.Parameters.AddWithValue("@itemnum", textBox3.Text);
            cmd.Parameters.AddWithValue("@itemname", textBox4.Text);
            cmd.Parameters.AddWithValue("@category", comboBox1.Text);
            cmd.Parameters.AddWithValue("@itemprice", textBox5.Text);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("ITEMS ADD SUCCESSFULLY");
            GetITEMS();
        }
        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            textBox3.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            textBox4.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            comboBox1.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            textBox5.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            String query = "DELETE FROM itemlist WHERE ITEMNUM=@itemnum";
            cmd = new OleDbCommand(query, conn);
            cmd.Parameters.AddWithValue("@itemnum", Convert.ToInt32(textBox3.Text)); ////query part
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show(" Items Delete Sucessfully");
            GetITEMS();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
