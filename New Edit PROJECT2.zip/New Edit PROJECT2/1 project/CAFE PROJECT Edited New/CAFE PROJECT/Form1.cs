﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace CAFE_PROJECT
{
    public partial class Form1 : Form
    {
        OleDbConnection conn;
        OleDbCommand cmd;
        OleDbDataAdapter adapter;
        OleDbDataReader reader;
        OleDbConnection connection;
        DataTable dt;

        public Form1()
        {
            InitializeComponent();
        }
        

        private void LABEL5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            form2 form = new form2();
            form.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Connection string for the database
            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DATAOFUSER1.accdb";
            string username = textBox1.Text;
            string password = textBox2.Text;

            // Check if the username or password fields are empty
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please Enter both username and password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                // Establish connection to the database
                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    // Open the connection
                    connection.Open();

                    // Define SQL query to retrieve password for the given username
                    string query = "SELECT PASSCODE FROM userdata WHERE USERNAME = @Username";

                    // Create a command object
                    using (OleDbCommand command = new OleDbCommand(query, connection))
                    {
                        // Add parameter for username
                        command.Parameters.AddWithValue("@Username", username);

                        // Execute the query and retrieve the password from the database
                        object result = command.ExecuteScalar();

                        if (result != null && result.ToString() == password)
                        {
                            // If password matches, login successful
                            MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            Form6 form6 = new Form6();
                            form6.Show();
                            this.Hide();
                        }
                        else
                        {
                            // If password does not match, display error message
                            MessageBox.Show("Invalid username or password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Error logging in: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
