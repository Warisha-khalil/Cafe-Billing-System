﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace CAFE_PROJECT
{
    public partial class form2 : Form
    {
        OleDbConnection conn;
        OleDbConnection conn2;
        OleDbCommand cmd;
        OleDbCommand cmd2;
        OleDbDataAdapter adapter;
        OleDbDataAdapter adapter2;
        OleDbDataReader reader;
        OleDbConnection connection;
        DataTable dt;
        DataTable dt2;

        DataTable dataTable;
        public form2()
        {
            InitializeComponent();
            if (!DesignMode)
            {
                // Initialize the DataTable
                dataTable = new DataTable();

                // Add columns to the DataTable
                dataTable.Columns.Add("Item_ID", typeof(string));
                dataTable.Columns.Add("Name", typeof(string));
                dataTable.Columns.Add("Category", typeof(string));
                dataTable.Columns.Add("Price", typeof(string));
                
            }
        }
        void GetITEMS()
        {
            conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Manageitems1.accdb");
            dt = new DataTable();
            adapter = new OleDbDataAdapter("SELECT *FROM itemlist ", conn);
            conn.Open();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        void GetDATA2()
        {

            conn2 = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PLACEORDER.accdb");
            dt2 = new DataTable();
            adapter2 = new OleDbDataAdapter("SELECT * FROM OrderData", conn2); // Enclose 'order' in square brackets
            conn2.Open();
            adapter2.Fill(dt2);
            dataGridView2.DataSource = dt2;
            conn2.Close();
        }
        void Getfilltercategory()
        {
            conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Manageitems1.accdb");
            dt = new DataTable();
            adapter = new OleDbDataAdapter("SELECT *FROM itemlist  WHERE CATEGORY='" + comboBox1.SelectedItem.ToString() + "'", conn);
            conn.Open();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        private void LABEL5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        decimal grand_total = 0;

        //decimal totalPrice = 0;
        DataTable table = new DataTable();

        int flag = 0;
        int sum = 0;

       

        // Initialize total price to zero
        

        private void button2_Click(object sender, EventArgs e)
        {
            // Check if a row is selected in dataGridView1
            if (selectedRowIndex >= 0)
            {
                // Get the selected row from dataGridView1
                DataGridViewRow selectedRow = dataGridView1.Rows[selectedRowIndex];

                // Extract data from the selected row
                string item_ID = selectedRow.Cells[0].Value.ToString();
                string name = selectedRow.Cells[1].Value.ToString();
                string category = selectedRow.Cells[2].Value.ToString();
                string priceString = selectedRow.Cells[3].Value.ToString();

                // Check if quantity is provided
                if (string.IsNullOrWhiteSpace(textBox3.Text))
                {
                    MessageBox.Show("Please enter a quantity.");
                    return;
                }

                // Parse the price and quantity
                decimal price;
                if (!decimal.TryParse(priceString, out price))
                {
                    MessageBox.Show("Invalid price.");
                    return;
                }

                int quantity;
                if (!int.TryParse(textBox3.Text, out quantity) || quantity <= 0)
                {
                    MessageBox.Show("Invalid quantity.");
                    return;
                }

                decimal totalPrice = price * quantity;
                grand_total = grand_total + totalPrice;
                label2.Text = "Rs  :  " + grand_total;

                // Add a new row to the dataTable
                DataRow newRow = dataTable.NewRow();
                newRow["Item_ID"] = item_ID;
                newRow["Name"] = name;
                newRow["Category"] = category;
                newRow["Price"] = totalPrice.ToString(); // Show the total price
                dataTable.Rows.Add(newRow);
               // CalculateTotalPrice();

                // Refresh dataGridView2 to reflect the changes
                dataGridView2.DataSource = null;
                dataGridView2.DataSource = dataTable;    
                textBox3.Text = "";
                // Calculate the total price
               

                //  label2.Text = "Rs  :  " + totalPrice;
            }
            else
            {
                MessageBox.Show("Please select a row in dataGridView1.");
            }
           
            

        }

      /*  private void CalculateTotalPrice()
        {
        

            // Iterate through all rows in dataGridView2
            foreach (DataGridViewRow row in dataGridView2.Rows)
            {
                // Extract the price from the current row
                if (row.Cells["Price"].Value != null)
                {
                    decimal price;
                    if (decimal.TryParse(row.Cells["Price"].Value.ToString(), out price))
                    {
                        // Add the price to the total
                        totalPrice += price;
                    }
                }
            }

            // Update the label2 text with the total price
            label2.Text = "Total: Rs " + totalPrice.ToString();
        }
      */


        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            flag = 1;
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 Login =new Form1();
            Login.Show();
        }

        private void form2_Load(object sender, EventArgs e)
        {
            GetITEMS();
            label4.Text = DateTime.Today.Date.ToString();

        }
        int num = 0;
        int total, qty;
        string item_ID, name, category, price;

        private void button3_Click(object sender, EventArgs e)
        {
            {
                string query = "INSERT INTO listoforders (ORDERNUM, TOTALPRICE, SELLERNAME) VALUES (@ordernum, @tprice, @sellernam)";
                using (conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=LISTOFORDERS1.accdb"))
                {
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@ordernum", textBox1.Text);
                        cmd.Parameters.AddWithValue("@tprice", label2.Text);
                        cmd.Parameters.AddWithValue("@sellernam", textBox2.Text);

                        try
                        {
                            conn.Open();
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("ORDER IS PLACED");
                            Gta();
                        }
                        catch (OleDbException ex)
                        {
                            MessageBox.Show("Error: " + ex.Message);
                        }
                        finally
                        {
                            conn.Close();
                        }
                    }
                }
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Getfilltercategory();    
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Update the selected row index
            selectedRowIndex = e.RowIndex;


        }

        int selectedRowIndex = -1;

        private void button6_Click(object sender, EventArgs e)
        {
            GetITEMS();
            Gta();
        }
        void Gta()
        {
            using (conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=LISTOFORDERS1.accdb;Mode=Share Deny None"))
            {
                dt = new DataTable();
                adapter = new OleDbDataAdapter("SELECT * FROM listoforders ", conn);
                conn.Open();
                adapter.Fill(dt);
                conn.Close();
            }
        }
    }
}
