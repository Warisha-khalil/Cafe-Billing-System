﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Windows.Forms;

namespace CAFE_PROJECT
{
    public partial class Form6 : Form
    {
        OleDbConnection conn;
        OleDbCommand cmd;
        OleDbDataAdapter adapter;
        OleDbDataReader reader;
        OleDbConnection connection;
        DataTable dt;

        public Form6()
        {
            InitializeComponent();

        }

        void GetDATA()
        {
            conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DATAOFUSER1.accdb");
            dt = new DataTable();
            adapter = new OleDbDataAdapter("SELECT * FROM userdata ", conn);
            conn.Open();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }
        private void label7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 form = new Form4();
            form.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 Login = new Form1();
            Login.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 form = new Form3();
            form.Show();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            
            GetDATA();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO userdata(ID,USERNAME,PHONE,PASSCODE)" +
                           "VALUES(@id, @Uname, @phone, @pw)";
            cmd = new OleDbCommand(query, conn);
            cmd.Parameters.AddWithValue("@id", textBox3.Text);
            cmd.Parameters.AddWithValue("@Uname", textBox1.Text);
            cmd.Parameters.AddWithValue("@phone", textBox4.Text);
            cmd.Parameters.AddWithValue("@pw", textBox5.Text);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("USERS DATA INSERTED SUCCESFULLY");
            GetDATA();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            
                String query = "DELETE FROM userdata WHERE ID=@id";
                cmd = new OleDbCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", Convert.ToInt32(textBox3.Text)); ////query part
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Users Data Delete Sucessfully");
                GetDATA();
            
        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            textBox3.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            textBox1.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textBox4.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            textBox5.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            String query = "UPDATE userdata SET USERNAME= @Uname,PHONE=@phone,PASSCODE=@pw WHERE ID=@id";
            cmd = new OleDbCommand(query, conn);
            cmd.Parameters.AddWithValue("@Uname", textBox1.Text);
            cmd.Parameters.AddWithValue("@phone", textBox4.Text);
            cmd.Parameters.AddWithValue("@pw", textBox5.Text);
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(textBox3.Text));
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show(" Users Update Sccessfully data");
            GetDATA();
        }
    }
}
