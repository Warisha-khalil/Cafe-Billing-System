﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Windows.Forms;
using System.Diagnostics;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Reflection.Emit;

namespace CAFE_PROJECT
{
    public partial class Form3 : Form
    {
        OleDbConnection conn;
        OleDbConnection conn2;
        OleDbCommand cmd;
        OleDbCommand cmd2;
        OleDbDataAdapter adapter;
        OleDbDataAdapter adapter2;
        OleDbDataReader reader;
        OleDbConnection connection;
        DataTable dt;
        DataTable dt2;

        DataTable dataTable;

        public Form3()
        {
            InitializeComponent();
            if (!DesignMode)
            {
                // Initialize the DataTable
                dataTable = new DataTable();

                // Add columns to the DataTable
                dataTable.Columns.Add("Item_ID", typeof(string));
                dataTable.Columns.Add("Name", typeof(string));
                dataTable.Columns.Add("Category", typeof(string));
                dataTable.Columns.Add("Price", typeof(string));
            }
        }
        void GetDATA()
        {
            conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=LISTOFORDERS1.accdb");
            dt = new DataTable();
            adapter = new OleDbDataAdapter("SELECT * FROM listoforders ", conn);
            conn.Open();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }
        void GetITEMS()
        {
            conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Manageitems1.accdb");
            dt = new DataTable();
            adapter = new OleDbDataAdapter("SELECT *FROM itemlist ", conn);
            conn.Open();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }
        void Getfilltercategory()
        {
            conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Manageitems1.accdb");
            dt = new DataTable();
            adapter = new OleDbDataAdapter("SELECT *FROM itemlist  WHERE CATEGORY='" + comboBox1.SelectedItem.ToString() + "'", conn);
            conn.Open();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }


        void GetDATA2()
        {

            conn2 = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PLACEORDER.accdb");
            dt2 = new DataTable();
            adapter2 = new OleDbDataAdapter("SELECT * FROM OrderData", conn2); // Enclose 'order' in square brackets
            conn2.Open();
            adapter2.Fill(dt2);
            dataGridView2.DataSource = dt2;
            conn2.Close();
        }


        private void LABEL5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 Login = new Form1();
            Login.Show();
        }




        private void button3_Click(object sender, EventArgs e)
        {

            {
                string query = "INSERT INTO listoforders (ORDERNUM, TOTALPRICE, SELLERNAME) VALUES (@ordernum, @tprice, @sellernam)";
                using (conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=LISTOFORDERS1.accdb"))
                {
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@ordernum", textBox1.Text);
                        cmd.Parameters.AddWithValue("@tprice",  label2.Text);
                        cmd.Parameters.AddWithValue("@sellernam", textBox2.Text);

                        try
                        {
                            conn.Open();
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("ORDER IS PLACED");
                            Gta();
                        }
                        catch (OleDbException ex)
                        {
                            MessageBox.Show("Error: " + ex.Message);
                        }
                        finally
                        {
                            conn.Close();
                        }
                    }
                }
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }


        /*  int num = 0;
          int total, qty;
          string item_ID,name,category,price;

          int selectedRowIndex = -1;*/

        decimal grand_total=0;

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Update the selected row index
            selectedRowIndex = e.RowIndex;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Check if a row is selected in dataGridView1
            if (selectedRowIndex >= 0)
            {
                // Get the selected row from dataGridView1
                DataGridViewRow selectedRow = dataGridView1.Rows[selectedRowIndex];

                // Extract data from the selected row
                string item_ID = selectedRow.Cells[0].Value.ToString();
                string name = selectedRow.Cells[1].Value.ToString();
                string category = selectedRow.Cells[2].Value.ToString();
                string priceString = selectedRow.Cells[3].Value.ToString();

                // Check if quantity is provided
                if (string.IsNullOrWhiteSpace(textBox3.Text))
                {
                    MessageBox.Show("Please enter a quantity.");
                    return;
                }

                // Parse the price and quantity
                decimal price;
                if (!decimal.TryParse(priceString, out price))
                {
                    MessageBox.Show("Invalid price.");
                    return;
                }

                int quantity;
                if (!int.TryParse(textBox3.Text, out quantity) || quantity <= 0)
                {
                    MessageBox.Show("Invalid quantity.");
                    return;
                }

                // Calculate the total price
               decimal totalPrice = price * quantity;
               grand_total = grand_total + totalPrice;
                label2.Text = "Rs  :  " + grand_total;

             

             
                // Add a new row to the dataTable
                DataRow newRow = dataTable.NewRow();
                newRow["Item_ID"] = item_ID;
                newRow["Name"] = name;
                newRow["Category"] = category;
                newRow["Price"] = totalPrice.ToString(); // Show the total price
                dataTable.Rows.Add(newRow);

                // Refresh dataGridView2 to reflect the changes
                dataGridView2.DataSource = null;
                dataGridView2.DataSource = dataTable;
                textBox3.Text = "";
            }
            else
            {
                MessageBox.Show("Please select a row in dataGridView1.");
            }



        }


        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            flag = 1;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }



        DataTable table = new DataTable();

        int flag = 0;
        int totalPrice = 0;


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Getfilltercategory();
        }

        private void comboBox1_SelectionChangeCommitted(object sender, EventArgs e)
        {
            Getfilltercategory();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            GetITEMS();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 form = new Form4();
            form.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 form = new Form6();
            form.Show();

        }
        int num = 0;
        int total, qty;
        string item_ID, name, category, price;

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form5 form = new Form5();
            form.Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        int selectedRowIndex = -1;

        private void Form3_Load(object sender, EventArgs e)
        {
            GetITEMS();
            GetDATA2();
           
            Gta();
        }
        void Gta()
        {
            using (conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=LISTOFORDERS1.accdb;Mode=Share Deny None"))
            {
                dt = new DataTable();
                adapter = new OleDbDataAdapter("SELECT * FROM listoforders ", conn);
                conn.Open();
                adapter.Fill(dt);
                conn.Close();
            }
        }
    }
}