﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Windows.Forms;

namespace CAFE_PROJECT
{
    public partial class Form5 : Form
    {
        OleDbConnection conn;
        OleDbCommand cmd;
        OleDbDataAdapter adapter;
        OleDbDataReader reader;
        OleDbConnection connection;
        DataTable dt;
        public Form5()
        {
            InitializeComponent();
        }
        private DataTable GetData()
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=LISTOFORDERS1.accdb";
            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                string query = "SELECT * FROM listoforders";
                using (OleDbCommand command = new OleDbCommand(query, connection))
                {
                    connection.Open();
                    using (OleDbDataReader reader = command.ExecuteReader())
                    {
                        DataTable dataTable = new DataTable();
                        dataTable.Load(reader);
                        return dataTable;
                    }
                }
            }
        }

        private void DisplayData()
        {
            DataTable dataTable = GetData();
            dataGridView1.DataSource = dataTable;
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            DisplayData();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 Login = new Form3();
            Login.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
      
        }
  

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            

           
           


        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
